import React from 'react'
import Main from './Main'

const Page = () => <Main />

export default Page