import Index from '@/app/components/my-institutes/Index'
import React from 'react'

const Page = () => <Index />

export default Page