import React from 'react'
import Main from './components/Table'

const Page = () => <Main />

export default Page